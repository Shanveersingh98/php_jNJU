@echo off
echo.
echo ========================================
echo   JANGJU - Installing PHP Libraries
echo ========================================
echo.

where composer >nul 2>&1
if %errorlevel% neq 0 (
    echo Composer not found! 
    echo.
    echo Download it from: https://getcomposer.org/Composer-Setup.exe
    echo Install it, then run this file again.
    pause
    exit
)

echo Installing PHPMailer and MongoDB library...
echo.
composer install
echo.
echo ========================================
echo   DONE! vendor/ folder created.
echo   Now upload ALL files to your hosting.
echo ========================================
pause
