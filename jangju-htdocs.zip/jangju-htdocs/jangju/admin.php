<?php
session_start();
require_once __DIR__ . '/config.php';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    if ($_POST['password'] === ADMIN_PASSWORD) {
        $_SESSION['jangju_admin'] = true;
    } else {
        $error = 'Wrong password';
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JANGJU Admin Panel</title>
<style>
:root { --gold:#C9A84C;--maroon:#3D0C02;--green:#15803d;--red:#dc2626; }
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Segoe UI',sans-serif;background:#0f0f0f;color:#eee;min-height:100vh;}
.login-screen{display:flex;align-items:center;justify-content:center;min-height:100vh;}
.login-card{background:#1a1a1a;border:1px solid #8B6914;border-radius:16px;padding:40px;width:340px;text-align:center;}
.login-card h2{color:var(--gold);margin-bottom:8px;}
.login-card p{color:#888;font-size:0.85rem;margin-bottom:28px;}
.login-input{width:100%;padding:12px 16px;background:#111;border:2px solid #333;border-radius:10px;color:#eee;font-size:1rem;outline:none;margin-bottom:16px;}
.login-btn{width:100%;background:linear-gradient(135deg,var(--gold),#8B6914);color:var(--maroon);border:none;padding:14px;border-radius:10px;font-weight:700;font-size:1rem;cursor:pointer;}
.error{color:var(--red);font-size:0.85rem;margin-top:10px;}
.header{background:linear-gradient(135deg,var(--maroon),#1a0800);padding:16px 24px;border-bottom:2px solid var(--gold);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;}
.header-logo{font-size:1.4rem;font-weight:900;color:var(--gold);}
.logout-btn{background:#333;color:#aaa;border:none;padding:8px 16px;border-radius:20px;font-weight:700;font-size:0.8rem;cursor:pointer;text-decoration:none;}
.stats-bar{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;padding:20px 24px;background:#111;border-bottom:1px solid #222;}
.stat-card{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:12px;padding:16px;text-align:center;}
.stat-num{font-size:2rem;font-weight:900;color:var(--gold);}
.stat-label{font-size:0.75rem;color:#888;font-weight:600;margin-top:4px;text-transform:uppercase;}
.toolbar{padding:16px 24px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;background:#111;border-bottom:1px solid #222;}
.search-input{flex:1;min-width:200px;padding:10px 16px;background:#1a1a1a;border:1px solid #333;border-radius:8px;color:#eee;font-size:0.9rem;outline:none;}
.export-btn{background:#1d4ed8;color:white;border:none;padding:10px 18px;border-radius:8px;font-weight:700;font-size:0.85rem;cursor:pointer;text-decoration:none;}
.orders-container{padding:20px 24px;}
.order-card{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:12px;padding:20px;margin-bottom:12px;border-left:4px solid var(--gold);}
.order-id{font-family:monospace;font-size:0.72rem;color:#555;margin-bottom:6px;}
.order-name{font-size:1.05rem;font-weight:700;}
.order-phone{color:var(--gold);font-size:0.9rem;}
.order-address{color:#aaa;font-size:0.82rem;margin-top:4px;}
.order-amount{font-size:1.2rem;font-weight:900;color:var(--gold);}
.order-top{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;}
.order-right{text-align:right;}
.order-meta{display:flex;align-items:center;justify-content:space-between;margin-top:14px;padding-top:12px;border-top:1px solid #2a2a2a;flex-wrap:wrap;gap:8px;}
.order-time{color:#555;font-size:0.78rem;}
.btn-whatsapp{background:#25d366;color:white;border:none;padding:6px 14px;border-radius:20px;font-size:0.78rem;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:5px;}
.badge{background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid rgba(34,197,94,0.3);font-size:0.72rem;font-weight:700;padding:3px 10px;border-radius:20px;}
.empty{text-align:center;padding:60px;color:#444;}
</style>
</head>
<body>

<?php if (!isset($_SESSION['jangju_admin'])): ?>
<!-- LOGIN -->
<div class="login-screen">
  <div class="login-card">
    <div style="font-size:2.5rem;margin-bottom:12px;">🦁</div>
    <h2>JANGJU Admin</h2>
    <p>Enter password to view orders</p>
    <form method="POST">
      <input type="password" name="password" class="login-input" placeholder="Admin Password" required autofocus>
      <button type="submit" class="login-btn">🔐 Login</button>
    </form>
    <?php if (isset($error)): ?>
      <div class="error">❌ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  </div>
</div>

<?php else: ?>
<!-- DASHBOARD -->
<?php
// Fetch orders from MongoDB
require_once __DIR__ . '/vendor/autoload.php';
$manager = new MongoDB\Driver\Manager(MONGO_URI);
$query   = new MongoDB\Driver\Query([], ['sort' => ['createdAt' => -1]]);
$cursor  = $manager->executeQuery(MONGO_DB . '.orders', $query);
$orders  = [];
foreach ($cursor as $doc) {
    $doc = (array)$doc;
    $doc['_id'] = (string)$doc['_id'];
    $doc['createdAt'] = isset($doc['createdAt'])
        ? $doc['createdAt']->toDateTime()->setTimezone(new DateTimeZone('Asia/Kolkata'))->format('d M Y, h:i A')
        : '—';
    $orders[] = $doc;
}

// Stats
$today     = date('d M Y');
$todayOrders = array_filter($orders, fn($o) => str_starts_with($o['createdAt'], $today));
$codOrders   = array_filter($orders, fn($o) => str_contains($o['payment'] ?? '', 'Cash'));
$revenue = 0;
foreach ($orders as $o) {
    preg_match('/[\d,]+/', $o['totalAmount'] ?? '', $m);
    if ($m) $revenue += (int)str_replace(',', '', $m[0]);
}
?>
<div class="header">
  <div class="header-logo">🦁 JANGJU Admin</div>
  <div style="display:flex;gap:10px;align-items:center;">
    <span style="color:#22c55e;font-size:0.8rem;font-weight:700;">● LIVE</span>
    <a href="?logout=1" class="logout-btn">Logout</a>
  </div>
</div>

<div class="stats-bar">
  <div class="stat-card"><div class="stat-num"><?= count($orders) ?></div><div class="stat-label">Total Orders</div></div>
  <div class="stat-card"><div class="stat-num"><?= count($todayOrders) ?></div><div class="stat-label">Today</div></div>
  <div class="stat-card"><div class="stat-num" style="font-size:1.3rem;">₹<?= number_format($revenue) ?></div><div class="stat-label">Est. Revenue</div></div>
  <div class="stat-card"><div class="stat-num"><?= count($codOrders) ?></div><div class="stat-label">COD Orders</div></div>
</div>

<div class="toolbar">
  <input type="text" class="search-input" id="search" placeholder="🔍 Search by name, phone, address..." oninput="filterOrders()">
  <button class="export-btn" onclick="exportCSV()">📥 Export CSV</button>
  <a href="index.html" class="export-btn" style="background:#3D0C02;">🏠 Website</a>
</div>

<div class="orders-container">
  <div id="orders-count" style="color:#888;font-size:0.85rem;margin-bottom:12px;">
    Showing <?= count($orders) ?> orders
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty">📭 No orders yet</div>
  <?php else: ?>
    <div id="orders-list">
    <?php foreach ($orders as $o):
      $phone  = preg_replace('/\D/', '', $o['phone'] ?? '');
      $waMsg  = urlencode("Hi {$o['name']}, your JANGJU order ({$o['quantity']}) is confirmed! Order ID: {$o['_id']}. We will ship soon. - Khalsa Dawakhana");
      $waLink = "https://wa.me/91{$phone}?text={$waMsg}";
    ?>
    <div class="order-card" data-name="<?= htmlspecialchars(strtolower($o['name'] ?? '')) ?>" data-phone="<?= htmlspecialchars($o['phone'] ?? '') ?>" data-address="<?= htmlspecialchars(strtolower($o['address'] ?? '')) ?>">
      <div class="order-top">
        <div>
          <div class="order-id">ID: <?= htmlspecialchars($o['_id']) ?></div>
          <div class="order-name">👤 <?= htmlspecialchars($o['name'] ?? '') ?></div>
          <div class="order-phone">📞 <?= htmlspecialchars($o['phone'] ?? '') ?></div>
          <div class="order-address">📍 <?= htmlspecialchars($o['address'] ?? '') ?></div>
        </div>
        <div class="order-right">
          <div class="order-amount"><?= htmlspecialchars($o['totalAmount'] ?? '—') ?></div>
          <div style="color:#aaa;font-size:0.82rem;">📦 <?= htmlspecialchars($o['quantity'] ?? '—') ?></div>
          <div style="color:#f59e0b;font-size:0.82rem;">💳 <?= htmlspecialchars($o['payment'] ?? '—') ?></div>
          <div style="margin-top:6px;"><span class="badge">✅ <?= htmlspecialchars($o['status'] ?? 'Confirmed') ?></span></div>
        </div>
      </div>
      <div class="order-meta">
        <div>
          <div class="order-time">🕐 <?= htmlspecialchars($o['createdAt']) ?></div>
          <?php if (!empty($o['message'])): ?>
            <div style="color:#888;font-size:0.8rem;font-style:italic;">💬 "<?= htmlspecialchars($o['message']) ?>"</div>
          <?php endif; ?>
        </div>
        <div style="display:flex;gap:8px;">
          <a class="btn-whatsapp" href="<?= $waLink ?>" target="_blank">💬 WhatsApp</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<script>
const allOrders = <?= json_encode($orders) ?>;

function filterOrders() {
  const q = document.getElementById('search').value.toLowerCase();
  document.querySelectorAll('.order-card').forEach(card => {
    const name    = card.dataset.name || '';
    const phone   = card.dataset.phone || '';
    const address = card.dataset.address || '';
    card.style.display = (!q || name.includes(q) || phone.includes(q) || address.includes(q)) ? '' : 'none';
  });
}

function exportCSV() {
  const headers = ['Order ID','Name','Phone','Address','Quantity','Amount','Payment','Message','Date'];
  const rows = allOrders.map(o => [
    o._id, o.name, o.phone, o.address, o.quantity, o.totalAmount, o.payment, o.message||'', o.createdAt
  ]);
  const csv = [headers,...rows].map(r => r.map(v => `"${(v||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  a.download = `jangju-orders-${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
}
</script>
<?php endif; ?>
</body>
</html>
